"""Rebuild reports from frozen API responses; no network access required."""
import base64
import hashlib
import html
import json
import re
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'data/metrica'
def read(name):return json.loads((D/(name+'.json')).read_text(encoding='utf-8'))
def fmt(x,n=2):return f'{x:,.{n}f}'.replace(',',' ').replace('.',',')
def total(name):return read(name)['totals']
def name(row):return ' / '.join(x.get('name','Не определено') if x else 'Не определено' for x in row['dimensions'])
def table(headers,rows):
 return '\n| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(str(x).replace('|','/') for x in row)+' |\n' for row in rows)+'\n'
def link(key):return f'[JSON](data/metrica/{key}.json) и [CSV](data/metrica/{key}.csv)'
def ranking(key,idx,kind,threshold=0):
 rows=[r for r in read(key)['data'] if r['metrics'][2]>=threshold and all(x and x.get('name')!='Not specified' for x in r['dimensions'])]
 best=(max if kind=='max' else min)(r['metrics'][idx] for r in rows)
 return [r for r in rows if r['metrics'][idx]==best]
def ranktext(rows,idx):return '; '.join(f"{name(r)} — {fmt(r['metrics'][idx])}, {fmt(r['metrics'][2],0)} визитов" for r in rows)

def build_metrica():
 all_=total('summary');ru=total('russia');org=total('search_total');mn=total('minsk')
 engines=read('search_engines')['data']; google=next(r for r in engines if name(r)=='Google');yandex=next(r for r in engines if name(r)=='Yandex')
 text=['# Анализ демосчётчика Яндекс Метрики за июнь 2024 года',
 'Период 01.06.2024–30.06.2024 включительно. Использован публичный демосчётчик 44147844. Это самостоятельное дополнение на другом сайте, не данные Google Merchandise Store. Все ответы ниже рассчитаны по сохранённым JSON API. Они не заменяют отсутствующие ответы GA4.',
 '## Условия расчётов',
 'Пользователи — ym:s:users; новые — ym:s:newUsers; визиты — ym:s:visits; глубина — ym:s:pageDepth; время — ym:s:avgVisitDurationSeconds, в секундах. Новый пользователь определяется историей идентификатора, а не обязательно первым визитом реального человека. Процент новых рассчитан из пользователей, а не из доли визитов новых посетителей. Метрика не предоставляет прямой эквивалент времени активного взаимодействия GA4.',
 f'Получение данных: {read("summary")["query"]["date1"]}–{read("summary")["query"]["date2"]}; запросы и время загрузки: [manifest.json](data/metrica/manifest.json). Все 15 запросов успешны, sampled=false и sample_share=1. Параметр accuracy=full. Область группировок с ym:s — визиты, с ym:pv — просмотры. В фактическом ответе API модель атрибуции: {read("summary")["query"].get("attribution")}.',
 f'Общий итог: **{fmt(all_[0],0)} посетителей**, {fmt(all_[1],0)} новых, {fmt(all_[2],0)} визитов, {fmt(all_[3],0)} просмотров; глубина {fmt(all_[4])}; время {fmt(all_[5])} секунды; отказы {fmt(all_[6])}%. Источник: '+link('summary')+'.',
 '## 1 Доля новых посетителей',
 f'{fmt(all_[1],0)} / {fmt(all_[0],0)} × 100% = **{fmt(all_[1]/all_[0]*100)}%**. Знаменатель — все посетители сайта. Источник: '+link('summary')+'.',
 '## 2 Популярные страницы на ПК и смартфонах',
 'Ранжирование по просмотрам, независимый фильтр категории устройства, limit=10. Использован URLPathFull, включая встречающиеся параметры и фрагменты: это рейтинг технических URL, без дополнительного объединения вариантов. Для сравнения контента без параметров следует повторить запрос с URLPath и проверить его определение. Итоги ym:pv могут не совпадать с просмотрами в визитной области ym:s; здесь они не смешиваются.'
 ]
 for key,title in [('pages_desktop','ПК'),('pages_mobile','Смартфоны')]:
  d=read(key)
  text += [f'### {title}',table(['Место','Путь URL с параметрами','Просмотры'],[(i,name(r),fmt(r['metrics'][0],0)) for i,r in enumerate(d['data'],1)]),f'Всего вариантов URL — {d["total_rows"]}; показано {len(d["data"])}. Источник: '+link(key)+'.']
 text += ['Для смартфонов API вернул только пять вариантов, поэтому десять строк искусственно не добавлены. В обоих сегментах лидирует /promo/product. Отдельные варианты с debug и status демонстрируют, почему полезна дополнительная очистка URL.',
 '## 3 Доля посетителей из России',f'{fmt(ru[0],0)} / {fmt(all_[0],0)} × 100% = **{fmt(ru[0]/all_[0]*100)}%**. Россия: {fmt(ru[2],0)} визитов; глубина {fmt(ru[4])}; время {fmt(ru[5])} секунды. Источник: '+link('russia')+'.',
 '## 4 Страны с максимальными глубиной и временем',
 'Без ограничения объёма, с сохранением совпавших максимумов:',
 'Глубина: '+ranktext(ranking('countries',4,'max'),4)+'. Время в секундах: '+ranktext(ranking('countries',5,'max'),5)+'.',
 'При минимум 30 визитах: глубина — '+ranktext(ranking('countries',4,'max',30),4)+'; время в секундах — '+ranktext(ranking('countries',5,'max',30),5)+'.',
 'Максимумы по одному визиту отвечают буквальному вопросу, но не характеризуют устойчивое поведение страны. 30 визитов — рабочий порог, не доказательство статистической значимости. Источник: '+link('countries')+'.',
 '## 5 Регионы России',
 'Лидеры и аутсайдеры названы отдельно по глубине и времени: общего единственного победителя без дополнительного критерия нет. Неизвестный регион не участвует в географическом рейтинге, но остаётся в исходных данных и знаменателях.'
 ]
 for threshold,label in [(0,'Без порога'),(30,'От 30 визитов')]:
  out=[]
  for idx,metric in [(4,'Глубина'),(5,'Время в секундах')]:
   for kind,title in [('min','Минимум'),('max','Максимум')]:
    for r in ranking('russian_regions',idx,kind,threshold):
     v=r['metrics'];out.append([metric,title,name(r),fmt(v[idx]),fmt(v[0],0),fmt(v[2],0),fmt(v[0]/ru[0]*100)+'%',fmt(v[0]/all_[0]*100)+'%'])
  text += [f'### {label}',table(['Метрика','Экстремум','Регион','Значение','Посетители','Визиты','Доля России','Доля сайта'],out)]
 text += ['Доли относятся к уникальным посетителям выбранного региона и отдельным общим итогам, а не сумме строк. Один посетитель может находиться в разных регионах. Источник: '+link('russian_regions')+'.',
 '## 6 Минск',f'Фильтр Belarus + Minsk. **{fmt(mn[0],0)} посетителя**, {fmt(mn[1],0)} новых; {fmt(mn[2],0)} визитов; {fmt(mn[3],0)} просмотра; глубина **{fmt(mn[4])}**; среднее время **{fmt(mn[5])} секунды**; отказы {fmt(mn[6])}%. Источник: '+link('minsk')+'.',
 '## 7 Популярный браузер и худшая версия',
 'В классификаторе Метрики Chrome Mobile и Google Chrome — отдельные строки. Семейства вручную не объединены. Лидер по посетителям — **Chrome Mobile, 2 889 посетителей, 3 029 визитов**. Следом Google Chrome — 1 757 посетителей. Источник: '+link('browsers')+'.'
 ]
 versions=[r for r in read('browser_versions')['data'] if r['dimensions'][0]['name']=='Chrome Mobile']
 out=[]
 for threshold in [0,30]:
  eligible=[r for r in versions if r['metrics'][2]>=threshold]
  for idx,label in [(4,'Минимум глубины'),(5,'Минимум времени')]:
   low=min(r['metrics'][idx] for r in eligible)
   for r in eligible:
    if r['metrics'][idx]==low:out.append([threshold,label,name(r),fmt(r['metrics'][idx]),fmt(r['metrics'][2],0)])
 text += [table(['Минимум визитов','Критерий','Версия','Значение','Визиты'],out),
 'Среди версий с минимум 30 визитами одна и та же версия **Chrome Mobile 122.0** имеет минимальные глубину 1,027 и время 13,84 секунды: 37 посетителей, 37 визитов. Именно она используется в следующем пункте; это выбор по заранее обозначенному правилу. Технический дефект из агрегатов не следует. Источник: '+link('browser_versions')+'.',
 '## 8 Российские регионы для Chrome Mobile 122 0']
 rr=[r for r in read('russian_browser_versions')['data'] if r['dimensions'][0]['name']=='Chrome Mobile' and r['dimensions'][1]['name']=='Chrome Mobile 122.0']
 text += [table(['Регион','Посетители','Визиты','Глубина','Время секунды'],[(r['dimensions'][2]['name'],fmt(r['metrics'][0],0),fmt(r['metrics'][2],0),fmt(r['metrics'][4]),fmt(r['metrics'][5])) for r in rr]),'Это полный отбор нужной версии из выгрузки сочетаний браузера, версии и региона. Перечень не ограничен первыми десятью строками. Источник: '+link('russian_browser_versions')+'.',
 '## 9 Мобильная модель и бренд',
 'Среди определённых моделей лидирует техническая метка **K — 1 739 посетителей**; iPhone — 292. Значение K нельзя уверенно назвать коммерческой моделью смартфона. Среди определённых брендов лидирует **Xiaomi — 354 посетителя**, Samsung — 351, Apple — 292. Рейтинги построены отдельно, фильтр — смартфоны.',
 f'Всего смартфонных посетителей — {fmt(total("devices")[0],0)}. У запроса моделей итог — {fmt(total("mobile_models")[0],0)}, у брендов — {fmt(total("mobile_brands")[0],0)}. Классификатор определяет модель и бренд не для всей аудитории; без отдельного сегмента неизвестных эти разности не следует выдавать за точное число неопределённых людей. Источники: '+link('mobile_models')+', '+link('mobile_brands')+' и '+link('devices')+'.',
 '## 10 Органический поиск и доля Google',
 f'Посетители с органического поиска — {fmt(org[0],0)}. Доля от сайта = {fmt(org[0],0)} / {fmt(all_[0],0)} × 100% = **{fmt(org[0]/all_[0]*100)}%**. Google внутри органики = {fmt(google["metrics"][0],0)} / {fmt(org[0],0)} × 100% = **{fmt(google["metrics"][0]/org[0]*100)}%**.',
 'Числитель и знаменатель получены на визитной области с одинаковым фильтром lastTrafficSource=organic. Итог органики получен отдельным запросом без группировок; посетители по поисковикам не складываются. Это не модель First user acquisition GA4. Источники: '+link('search_total')+' и '+link('search_engines')+'.',
 '## 11 Google и Яндекс в органическом поиске',
 table(['Показатель','Google','Яндекс'],[(label,fmt(google['metrics'][i],digits),fmt(yandex['metrics'][i],digits)) for i,label,digits in [(0,'Посетители',0),(2,'Визиты',0),(4,'Глубина',3),(5,'Время секунды',2),(6,'Отказы проценты',2)]]),
 'Google даёт 359 визитов, Яндекс — 155, отношение 2,32. У Яндекса выше глубина на 0,292 страницы за визит и время на 89,89 секунды. При этом отказы Яндекса выше на 4,16 процентного пункта. Сходство: у обеих групп средняя глубина ниже двух страниц и доля отказов превышает 60%. Более длительное среднее время не означает автоматически меньше отказов: это разные характеристики распределения. Причины, качество лидов и статистическая значимость этим анализом не установлены. Источник: '+link('search_engines')+'.',
 '## Проверка данных и трактовки',
 'Проверены отсутствие семплирования, полнота непагинированных выгрузок, отдельные знаменатели долей и арифметическое соответствие глубины отношению просмотров к визитам. Строки неизвестных значений могут отсутствовать в отдельных группировках, поэтому их totals отличаются от отдельного общего запроса. Знаменатель сайта всегда берётся из summary.json. Статистику двух сервисов нельзя сверять как одну и ту же аудиторию: здесь разные сайты и разные правила измерения.',
 '## Официальные источники',
 '- [Примеры запросов к публичному демосчётчику](https://yandex.com/dev/metrika/en/stat/examples).\n- [Список параметров и метрик](https://yandex.ru/dev/metrika/ru/stat/attrandmetr/dim_all).\n- [Настройка отчётов Метрики](https://www.yandex.ru/support/metrica/ru/reports/report-general).'
 ]
 (ROOT/'Яндекс_Метрика_ответы.md').write_text('\n\n'.join(text)+'\n',encoding='utf-8')

def inline(text):
 text=html.escape(text)
 text=re.sub(r'`([^`]+)`',r'<code>\1</code>',text)
 text=re.sub(r'\*\*([^*]+)\*\*',r'<strong>\1</strong>',text)
 text=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',r'<a href="\2">\1</a>',text)
 return text
def markdown(text):
 lines=text.splitlines();out=[];i=0
 while i<len(lines):
  line=lines[i]
  if not line.strip():i+=1;continue
  if line.startswith('|'):
   block=[]
   while i<len(lines) and lines[i].startswith('|'):block.append(lines[i]);i+=1
   out.append('<div class="table"><table>')
   for j,row in enumerate(block):
    if j==1:continue
    tag='th' if j==0 else 'td';out.append('<tr>'+''.join(f'<{tag}>{inline(c.strip())}</{tag}>' for c in row.strip('|').split('|'))+'</tr>')
   out.append('</table></div>');continue
  match=re.match(r'^(#{1,3}) (.*)',line)
  if match:level=len(match[1]);out.append(f'<h{level}>{inline(match[2])}</h{level}>')
  elif line.startswith('- '):out.append('<p class="item">• '+inline(line[2:])+'</p>')
  else:out.append('<p>'+inline(line)+'</p>')
  i+=1
 return '\n'.join(out)

def build_html():
 files=['README.md','GA4_ответы.md','Яндекс_Метрика_ответы.md','PowerBI_решение.md','Конспект.md']
 out=['<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GA4 Яндекс Метрика Power BI</title>',
 '<style>body{margin:0;font:17px/1.65 "Segoe UI",Arial,sans-serif;color:#203446;background:#f3f6f8}main{max-width:1160px;margin:auto;background:white;padding:48px 60px}h1{font-size:32px;line-height:1.25;margin:52px 0 24px}h2{font-size:25px;margin-top:40px}h3{font-size:20px}p{max-width:100ch}a{color:#12659b}code{background:#edf3f7;padding:2px 4px;overflow-wrap:anywhere}table{border-collapse:collapse;min-width:70%;font-size:15px;line-height:1.45}td,th{border:1px solid #d5dfe7;padding:12px;text-align:left;overflow-wrap:anywhere}th{background:#183c58;color:white}tr:nth-child(even){background:#f2f7fa}.table{overflow:auto}nav{position:sticky;top:0;background:#173b56;padding:14px;color:white;z-index:2}nav a{color:white;margin-right:18px}img{max-width:100%;height:auto}figure{margin:32px 0}figcaption{font-size:14px;color:#506477}section{border-top:1px solid #d5dfe7;margin-top:36px}@media(max-width:750px){main{padding:20px}nav{position:static}}@media print{nav{display:none}body{background:white}main{padding:0}h2,h3{break-after:avoid}tr,figure{break-inside:avoid}}</style>',
 '<nav><a href="#overview">Состав</a><a href="#ga4">GA4</a><a href="#ym">Метрика</a><a href="#pbi">Power BI</a><a href="#notes">Конспект</a><a href="#evidence">Скриншоты</a></nav><main>']
 for key,file in zip(['overview','ga4','ym','pbi','notes'],files):
  if (ROOT/file).exists():out.append(f'<section id="{key}">'+markdown((ROOT/file).read_text(encoding='utf-8'))+'</section>')
 out.append('<section id="evidence"><h1>Исходные скриншоты GA4</h1><p>Извлечены из прежнего решения. Это архивные доказательства, не новые скриншоты из аккаунта. Номер совпадает с именем imageN.jpg.</p>')
 hashes=[]
 for p in sorted((ROOT/'evidence').glob('image*.jpg'),key=lambda p:int(re.search(r'\d+',p.name)[0])):
  out.append(f'<figure id="{p.stem}"><figcaption>{p.name}</figcaption><img loading="lazy" alt="Архивный скриншот GA4 {p.stem}" src="data:image/jpeg;base64,{base64.b64encode(p.read_bytes()).decode()}"></figure>')
  hashes.append({'file':'evidence/'+p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 shot=ROOT/'powerbi/Матрица.jpg'
 if shot.exists():out.append('<h2>Матрица в Power BI Desktop</h2><img alt="Матрица Power BI" src="data:image/jpeg;base64,'+base64.b64encode(shot.read_bytes()).decode()+'">')
 out.append('</section></main></html>')
 result='\n'.join(out)
 # Point archive links at embedded evidence, so they work offline as one file.
 result=re.sub(r'href="evidence/(image\d+)\.jpg"',r'href="#\1"',result)
 (ROOT/'Отчёт.html').write_text(result,encoding='utf-8')
 (ROOT/'evidence/manifest.json').write_text(json.dumps(hashes,ensure_ascii=False,indent=2),encoding='utf-8')

def verify():
 manifest=json.loads((D/'manifest.json').read_text(encoding='utf-8'))
 assert len(manifest)==15 and all(x['status']=='ok' and x['sampled'] is False for x in manifest)
 for x in manifest:
  d=read(x['name']);assert d['query']['date1']=='2024-06-01' and d['query']['date2']=='2024-06-30'
  assert len(d['data'])==min(d['total_rows'],d['query']['limit'])
  if 'ym:s:pageDepth' in d['query']['metrics']:
   for r in d['data']:
    m=r['metrics'];assert abs(m[4]-m[3]/m[2])<1e-6
 print('Verified: 15 successful unsampled queries, dates, completeness, row depth ratios')

if __name__=='__main__':
 verify();build_metrica();build_html()
